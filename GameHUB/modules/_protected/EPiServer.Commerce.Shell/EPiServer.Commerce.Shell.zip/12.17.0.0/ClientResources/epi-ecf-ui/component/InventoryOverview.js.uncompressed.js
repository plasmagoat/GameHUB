require({cache:{
'url:epi-ecf-ui/component/templates/InventoryOverview.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-type=\"epi-ecf-ui/widget/InventoryOverview\" data-dojo-attach-point=\"overviewWidget\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/component/InventoryOverview", [
// dojo
    "dojo/_base/declare",
// commerce
    "./_OverviewBase",
// resources
    "dojo/text!./templates/InventoryOverview.html",
    "epi/i18n!epi/cms/nls/commerce.components.inventoryoverview",
// Widgets in the template
    "epi-cms/contentediting/StandardToolbar",
    "../widget/InventoryOverview"
], function (
// dojo
    declare,
// commerce
    _OverviewBase,
// resources
    template,
    resources
) {
    return declare([_OverviewBase], {
        // summary:
        //      This is the initializer of Inventory Overview.
        resources: resources,

        templateString: template
    });
});
