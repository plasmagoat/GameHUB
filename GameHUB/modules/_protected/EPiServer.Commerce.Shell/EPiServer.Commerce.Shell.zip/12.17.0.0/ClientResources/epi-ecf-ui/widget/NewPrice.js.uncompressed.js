﻿define("epi-ecf-ui/widget/NewPrice", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/keys",
    "dojo/on",
    "dijit/focus",
    "epi/shell/widget/FormContainer",
    "../contentediting/editors/_KeyboardBlurMixin",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
], function(
    array,
    declare,
    aspect,
    keys,
    on,
    focusUtil,
    FormContainer,
    _KeyboardBlurMixin,
    resources
){
    return declare([FormContainer, _KeyboardBlurMixin], {

        priceCodeWidget: null,

        priceTypeWidget: null,

        marketWidget: null,

        unitPriceWidget: null,

        fromWidget: null,

        untilWidget: null,

        onFieldCreated: function (fieldName, widget) {
            if (fieldName === "priceType"){
                this.priceTypeWidget = widget;
                this.own(
                    this.priceTypeWidget,
                    this.priceTypeWidget.on("change", this._updatePriceCodeWidget.bind(this))
                );
            } else if (fieldName === "marketId") {
                this.marketWidget = widget;
                this.own(
                    this.marketWidget,
                    this.marketWidget.on("change", this._updateCurrencyWidget.bind(this))
                );
            } else if (fieldName === "priceCode"){
                this.priceCodeWidget = widget;
                this.own(this.priceCodeWidget);
            } else if (fieldName === "unitPrice"){
                this.unitPriceWidget = widget;
                this.own(this.unitPriceWidget);
            } else if (fieldName.indexOf("From") >= 0) {
                //indexOf is used as it must work both for both PriceModel (validDate.validFrom) as well
                //as for only DateTimeRange (validFrom).
                this.fromWidget = widget;
                this.fromWidget.set("rangeMessage", resources.notvaliddaterange);
                this.own(
                    this.fromWidget,
                    this.fromWidget.on("change", this._setToConstraints.bind(this))
                );
            } else if (fieldName.indexOf("Until") >= 0) {
                //indexOf is used as it must work both for both PriceModel (validDate.validUntil) as well
                //as for only DateTimeRange (validUntil).
                this.untilWidget = widget;
                this.untilWidget.set("rangeMessage", resources.notvaliddaterange);
                this.own(
                    this.untilWidget,
                    this.untilWidget.on("change", this._setFromContraints.bind(this))
                );
                //if from widget exists and contains a value we can set the constraints
                if (this.fromWidget){
                    this._setToConstraints(this.fromWidget.get("value"));
                    this._setFromContraints(this.untilWidget.get("value"));
                }
            }
        },

        _updatePriceCodeWidget: function(newPriceType){
            var customerPriceGroupType = 2;
            this.priceCodeWidget.showDropDown(newPriceType === customerPriceGroupType);
        },

        _updateCurrencyWidget: function(newMarketId){
            this.unitPriceWidget.setCurrencySelections(newMarketId);
        },

        _setToConstraints: function (newMinimumDate) {
            if (newMinimumDate){
                this.untilWidget.set("constraints", { min: newMinimumDate });
            }
        },

        _setFromContraints: function (newMaximumDate) {
            if (newMaximumDate){
                this.fromWidget.set("constraints", { max: newMaximumDate});
            }
            else {
                this.fromWidget.set("constraints", {});
            }
        },

        focus: function(){
            if (this.marketWidget){
                this.marketWidget.focus();
            } else if(this.fromWidget){
                this.fromWidget.focus();
            }
            this.inherited(arguments);
        },

        onFormCreated: function(){
            this.inherited(arguments);
            this.focus();
        }
    });
});