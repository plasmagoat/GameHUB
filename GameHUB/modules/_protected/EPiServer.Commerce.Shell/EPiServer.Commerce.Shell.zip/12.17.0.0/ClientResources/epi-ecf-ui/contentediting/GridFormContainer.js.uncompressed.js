require({cache:{
'url:epi-ecf-ui/contentediting/templates/GridFormContainer.html':"<div class='epi-containerLayout clearfix'>\r\n    <div class='epi-formsHeaderContainer'>\r\n        <h2>${title}</h2>\r\n        <p data-dojo-attach-point='helpTextNode'></p>\r\n    </div>\r\n    <ul data-dojo-attach-point='containerNode'></ul>\r\n</div>"}});
define("epi-ecf-ui/contentediting/GridFormContainer", [
// dojo
    "dojo/_base/declare",
    "dojo/when",
// epi
    "epi/shell/TypeDescriptorManager",
    "epi/shell/layout/SimpleContainer",
// epi-cms
    "epi-cms/_ContentContextMixin",
// resources
    "dojo/text!./templates/GridFormContainer.html"
], function(
// dojo
    declare,
    when,
// epi
    TypeDescriptorManager,
    SimpleContainer,
// epi-cms
    _ContentContextMixin,
// resources
    template
){
    return declare([SimpleContainer, _ContentContextMixin], {

        templateString: template,

        typeDescriptorManager: TypeDescriptorManager,

        buildRendering: function(){
            this.inherited(arguments);

            when(this.getCurrentContent()).then(function (currentContext) {
                var specificGroupResources;
                var allGroupResources = this.typeDescriptorManager.getResourceValue(currentContext.typeIdentifier, "groups");

                if (allGroupResources) {
                    specificGroupResources = allGroupResources[this.name.toLowerCase()];
                }

                if (specificGroupResources && specificGroupResources.help) {
                    this.set("helpText", specificGroupResources.help);
                }
            }.bind(this));
            
        },

        _setHelpTextAttr: { node: "helpTextNode", type: "innerHTML" }
    });
});