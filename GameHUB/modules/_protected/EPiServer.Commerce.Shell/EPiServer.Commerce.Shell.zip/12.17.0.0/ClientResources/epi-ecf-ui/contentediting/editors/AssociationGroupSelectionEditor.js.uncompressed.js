﻿define("epi-ecf-ui/contentediting/editors/AssociationGroupSelectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/when",
    // dijit
    "dijit/form/Select",
    // epi
    "epi/dependency",
    "epi/shell/_ContextMixin"
], function(
    // dojo
    declare,
    when,
    // dijit
    Select,
    // epi
    dependency,
    // epi-cms
    _ContextMixin
) {
    return declare([Select, _ContextMixin], {
        storeKey: "epi.commerce.associationgroupdefinition",

        constructor: function() {
            this.labelAttr = "name";
        },

        startup: function () {
            this.inherited(arguments);

            // To avoid an extra call and possible duplicated items in the select list
            // (caused by race condition), don't set the store before inherited startup.
            // Also, we need the context to set the query, so start getting that async
            // here to avoid it finishing before inherited startup.
            when(this.getCurrentContext(), function (ctx, callerData) {
                this._refreshStore(ctx.id);
            }.bind(this));
        },

        contextChanged: function(ctx, callerData) {
            this.inherited(arguments);
            this._refreshStore(ctx.id);
        },

        _refreshStore: function (contentLink) {
            // When hit the first time, store won't be set and we have to get it from the registry
            // We can't set store earlier because of reasons described above
            var store = this.get("store") || dependency.resolve("epi.storeregistry").get(this.storeKey);

            // This doesn't actually replace the store, because it is recognized as the same,
            // but it is the only way to update the select items from a new query
            this.setStore(store, this.get("value"), { query: { id: contentLink } });
        }
    });
});