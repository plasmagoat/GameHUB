﻿define("epi-ecf-ui/widget/viewmodel/_MarketingListBaseModel", [
// dojo
    "dojo/_base/declare",
// epi-cms
    "epi/shell/command/_CommandProviderMixin",
// epi-ecf-ui
    "../../MarketingUtils"
],
function (
// dojo
    declare,
// epi-cms
    _CommandProviderMixin,
// epi-ecf-ui
    MarketingUtils
) {

    return declare([_CommandProviderMixin], {
        _getNameModel: function (item) {
            return {
                typeIdentifier: item.typeIdentifier,
                name: item.name,
                group: this._getPromotionGroup(item.typeIdentifier)
            };
        },

        _getItemType: function (typeIdentifier) {
            if (MarketingUtils.isSalesCampaign(typeIdentifier)) {
                return this.itemType.campaign;
            }
            if (MarketingUtils.isPromotionData(typeIdentifier)) {
                return this.itemType.promotion;
            }
            return this.itemType.notSet;
        },

        _getRedemptionCount: function (item) {
            if (MarketingUtils.isPromotionData(item.typeIdentifier)) {
                return item.properties.redemptions;
            }
            return null;
        },

        _getTotalOrderModel: function (item) {
            return {
                count: item.properties.orderCount || 0,
                isSalesCampaign: MarketingUtils.isSalesCampaign(item.typeIdentifier)
            };
        },

        _getStatusModel: function (item) {
            var validFrom = new Date(item.properties.validFrom);
            var validUntil = new Date(item.properties.validUntil);

            return {
                status: item.properties.status,
                statusLabelKey: this._getStatus(item),
                validFrom: validFrom,
                validUntil: validUntil,
                typeIdentifier: item.typeIdentifier,
                campaignStatus: item.properties.campaignStatus,
                followsCampaignSchedule: item.properties.followsCampaignSchedule,
                redemptions: this._getRedemptionCount(item)
            };
        },

        _getStatus: function (item) {
            return MarketingUtils.getStatusString(item.properties.status);
        },

        _getPromotionGroup: function (typeIdentifier) {
            if (MarketingUtils.isEntryPromotion(typeIdentifier)) {
                return "entry";
            }
            if (MarketingUtils.isOrderPromotion(typeIdentifier)) {
                return "order";
            }
            if (MarketingUtils.isShippingPromotion(typeIdentifier)) {
                return "shipping";
            }
            if (MarketingUtils.isPromotionData(typeIdentifier)) {
                return "discount";
            }
            return null;
        }
    });
});